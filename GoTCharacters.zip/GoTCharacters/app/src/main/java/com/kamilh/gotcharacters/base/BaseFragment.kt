package com.kamilh.gotcharacters.base

import dagger.android.support.DaggerFragment

abstract class BaseFragment : DaggerFragment()
